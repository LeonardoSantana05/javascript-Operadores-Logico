/*A função parseInt converte seu primeiro argumento para uma string,
e retorna um inteiro ou NaN. Se não NaN, o valor retornado será a representação decimal 
inteira do primeiro argumento obtido como um número na base especificada.*/
/*let inteira = parseInt(021, 8);
console.log(inteira);
/*A função parseFloat analisa um argumento 
(convertendo-o para uma string primeiro caso necessário) 
e retorna um número de ponto flutuante (número decimal).*/
/*var decimal = parseFloat(3.14);
console.log(decimal);

const infinit = parseFloat(03445,15);


console.log(infinit+decimal+inteira);


let inteira = parseInt(021, 8);
const infinit = parseFloat(03445,15);
var decimal = parseFloat(3.14);

console.log(infinit-decimal-inteira);


let inteira = parseInt(021, 8);
const infinit = parseFloat(03445,15);
var decimal = parseFloat(3.14);

console.log(infinit*decimal*inteira);

let inteira = parseInt(021, 8);
const infinit = parseFloat(03445,15);
var decimal = parseFloat(3.14);

console.log(infinit/decimal/inteira);*/

let inteira = parseInt(021, 8);
const infinit = parseFloat(03445,15);
var decimal = parseFloat(3.14);
var ingma = parseInt (1334, 16);
let corsair = parseFloat (786, 16);


console.log(infinit*decimal+inteira-ingma/corsair);